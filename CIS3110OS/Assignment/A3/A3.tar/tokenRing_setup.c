/*
 * The program simulates a Token Ring LAN by forking off a process
 * for each LAN node, that communicate via shared memory, instead
 * of network cables. To keep the implementation simple, it jiggles
 * out bytes instead of bits.
 *
 * It keeps a count of packets sent and received for each node.
 */
 #include <stdio.h>
 #include <signal.h>
 #include <sys/time.h>
 #include <sys/ipc.h>
 #include <sys/shm.h>
 #include <sys/sem.h>
 #include <sys/types.h>
 #include <sys/wait.h>
 #include <time.h>
 #include <stdlib.h>
 #include <unistd.h>
 #include <stdarg.h>
 #include <string.h>
 #include <errno.h>
 #include <pthread.h>

 #include "tokenRing.h"
 
 pthread_t workers[N_NODES];

 /*
  * The main program creates the shared memory region and forks off the
  * processes to emulate the token ring nodes.
  * This process generates packets at random and inserts them in
  * the to_send field of the nodes. When done it waits for each process
  * to be done receiving and then tells them to terminate and waits
  * for them to die and prints out the sent/received counts.
  */
 struct TokenRingData *
 setupSystem()
 {
	 register int i;
	 struct TokenRingData *control;
 
	 control = (struct TokenRingData *)malloc(sizeof(struct TokenRingData));
 
	 /*
	  * Seed the random number generator.
	  */
	 srandom(time(0));
 
	 /*
	  * Replace with malloc from shared_memory
	  */
	  control->shared_ptr = (struct shared_data *)malloc(sizeof(struct shared_data));
	  if (control->shared_ptr == (struct shared_data *)0) {
		  fprintf(stderr, "Can't initialize shared_data\n");
		  goto FAIL;
	  }
 
	 /*
	  * Create the semaphore set.
	  */
	 control->semid = semget(IPC_PRIVATE, NUM_SEM, 0600);
	 if (control->semid < 0) {
		 fprintf(stderr, "Can't create semaphore set\n");
		 goto FAIL;
	 }
 
	 /*
	  * Initialize semaphores.
	  */
	for (i = 0; i < N_NODES; i++) {
		 INITIALIZE_SEM(control, TO_SEND(i), 1);
 
		 INITIALIZE_SEM(control, EMPTY(i), 1);
 
		 INITIALIZE_SEM(control, FILLED(i), 0);
	 }
 
	 // CRIT
	 INITIALIZE_SEM(control, CRIT, 1);
 
	 /*
	  * Initialize the shared data.
	  */
	 for (i = 0; i < N_NODES; i++) {
		 control->shared_ptr->node[i].data_xfer = -1;       
		 control->shared_ptr->node[i].sent = 0;             
		 control->shared_ptr->node[i].received = 0;         
		 control->shared_ptr->node[i].terminate = 0;         
		 control->shared_ptr->node[i].to_send.token_flag = TOKEN_FLAG; 
		 control->shared_ptr->node[i].to_send.to = 0;
		 control->shared_ptr->node[i].to_send.from = 0;
		 control->shared_ptr->node[i].to_send.length = 0;
		 memset(control->shared_ptr->node[i].to_send.data, 0, MAX_DATA);
	 }
 
	 control->snd_state = TOKEN_FLAG; 
 
 #ifdef DEBUG
	 fprintf(stderr, "main after initialization\n");
 #endif
 
	 return control;
 
 FAIL:
 	 free(control->shared_ptr);
	 free(control);
	 
	 return NULL;
 }
 
void wake_up_handler(int signo) {
#ifdef DEBUG
    fprintf(stderr, "[SERVER] Ready to send another packet!\n");
#endif
}

void *worker_thread(void *arg) {
    ThreadArgs *args = (ThreadArgs *)arg;  //Args
    token_node(args->control, args->nodeIndex, args->pid);
    return NULL;
}

 int
 runSimulation(control, numberOfPackets)
	 struct TokenRingData *control;
	 int numberOfPackets;
 {
	 int num, to, totalSent = 0;
	 int i;
 
	 /*
	  * Replace processes to threads
	  */
	  ThreadArgs args[N_NODES];   

	  for (int i = 0; i < N_NODES; i++) {
		args[i].control = control; 
		args[i].nodeIndex = i;   
		args[i].pid = getpid();   
		pthread_create(&workers[i], NULL, worker_thread, &args[i]);
#ifdef DEBUG
		   fprintf(stderr, "[SERVER] Created node %d\n", i);
#endif
	  }
 
	 /*
	  * Loop around generating packets at random.
	  * (the parent)
	  */
	 for (i = 0; i < numberOfPackets; i++) {
		 /*
		  * Add a packet to be sent to to_send for that node.
		  */
		  signal(SIGUSR1, wake_up_handler);
#ifdef DEBUG
		  fprintf(stderr, "Main in generate packets\n");
#endif
		 num = random() % N_NODES;
		 WAIT_SEM(control, TO_SEND(num));

		 if (control->shared_ptr->node[num].to_send.length > 0)
			 panic("to_send filled\n");
 
		 control->shared_ptr->node[num].to_send.token_flag = 0x00;
 
 
		 do {
			 to = random() % N_NODES;
		 } while (to == num);
 
		 control->shared_ptr->node[num].to_send.to = (char)to;
		 control->shared_ptr->node[num].to_send.from = (char)num;
		 control->shared_ptr->node[num].to_send.length = (random() % MAX_DATA) + 1;

		 printf("A packet is being sent : i=%d, from=%d, to=%d, length=%d\n",
			 i+1, num, to, control->shared_ptr->node[num].to_send.length);


#ifdef DEBUG
		 fprintf(stderr, "[SERVER] Wait until the packet gets delievered\n");
#endif
		 sleep(10);
	 }
 
	 // Wait for all packets to be sent
	 while (totalSent < numberOfPackets) {
		 totalSent = 0;
		 for (int i = 0; i < N_NODES; i++) {
			// Check if all packets have been sent
			totalSent += control->shared_ptr->node[i].sent;
		 }
		 usleep(10); 

		 //print the totalSent variable and the number of packets
#ifdef DEBUG
		 fprintf(stderr, "[SERVER] Total packets sent: %d/%d\n", totalSent, numberOfPackets);
#endif
	 }

	 //Print that all packets have been sent
#ifdef DEBUG
	fprintf(stderr, "[SERVER] All packets have been sent. Now server starts cleaning up the system...\n");
#endif

	 return 1;
 }
 
 int
 cleanupSystem(control)
	 struct TokenRingData *control;
 {
	 union semun zeroSemun;
	 int i;
 
	 bzero(&zeroSemun, sizeof(union semun));
	 /*
	  * Now wait for all nodes to finish sending and then tell them
	  * to terminate.
	  */
#ifdef DEBUG
	  fprintf(stderr, "wait for children to terminate\n");
#endif
	 for (i = 0; i < N_NODES; i++)
		 WAIT_SEM(control, TO_SEND(i));
	
	 WAIT_SEM(control, CRIT);
	 for (i = 0; i < N_NODES; i++)	 
		control->shared_ptr->node[i].terminate = 1;
	 SIGNAL_SEM(control, CRIT);

	// Then in cleanup, join them:
	for (int i = 0; i < N_NODES; i++) {
		int res = pthread_join(workers[i], NULL);
		if (res == 0) {
#ifdef DEBUG
	  fprintf(stderr, "[DEBUG] Thread %d successfully joined.\n", i);
#endif
		} else {
#ifdef DEBUG
	  fprintf(stderr, "[DEBUG] Error joining thread %d: %s\n", i, strerror(res));
#endif
		}
	}


	 /*
	  * All done, just print out the results.
	  */
	 for (i = 0; i < N_NODES; i++)
		 printf("Node %d: sent=%d received=%d\n", i,
			 control->shared_ptr->node[i].sent,
			 control->shared_ptr->node[i].received);
 #ifdef DEBUG
	 fprintf(stderr, "All threads have been destroyed\n");
 #endif
	 /*
	  * And destroy the shared data area and semaphore set.
	  */
	 semctl(control->semid, 0, IPC_RMID, zeroSemun);
 
	 free(control->shared_ptr);
	 free(control);
	 return 1;
 }
 
 
 /*
  * Panic: Just print out the message and exit.
  */
 void
 panic(const char *fmt, ...)
 {
		 va_list vargs;
 
	 va_start(vargs, fmt);
	 (void) vfprintf(stdout, fmt, vargs);
	 va_end(vargs);
 
	 exit(5);
 }
 
 
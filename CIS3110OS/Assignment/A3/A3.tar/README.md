# Assignment 3: Multi-Threaded Token Ring Simulation
**Author: Soohwan Kim (1349765)**

## **Assignment Description**
This project extends the previous **Token Ring Simulation** by replacing the **multi-process architecture** (used in Assignment 2) with a **multi-threaded design**. The simulation now utilizes **POSIX threads (pthreads)** instead of creating separate processes for each node, leading to better performance and reduced memory overhead.

The goal remains the same: to **simulate a token-passing network**, where multiple **nodes (threads)** communicate in a circular manner, passing a **token** that grants permission to send data.

## **Changes from Assignment 2**
The following key changes were made when transitioning from **multi-process** to **multi-threaded** architecture:

| **Feature**             | **Assignment 2 (Multi-Process)** | **Assignment 3 (Multi-Threaded)** |
|-------------------------|--------------------------------|----------------------------------|
| Node Implementation    | Each node was a separate **process** (`fork()`). | Each node is now a **thread** (`pthread_create()`). |
| Inter-Process Communication | **Shared Memory (shmget, shmat)** | **Heap-allocated shared data (`malloc()`)** |
| Synchronization        | **Semaphores (SysV `semget`)** | **Semaphores (SysV `semget`) remain the same** |
| Process Termination    | **`waitpid()` used to clean up child processes** | **`pthread_join()` used to wait for threads** |

By replacing processes with threads, we eliminate the **overhead of process creation** and **context switching**, making the program more efficient.

---

## **Program Design and Architecture**
### **1. System Components**
The new **multi-threaded token ring simulation** consists of the following components:

1. **Main Thread (Controller)**
   - Initializes shared memory (now allocated with `malloc()`).
   - Initializes semaphores for synchronization.
   - Creates a thread (`pthread_create`) for each node in the token ring.
   - Generates packets randomly and assigns them to nodes.
   - Waits for all packets to be processed and terminates the simulation.

2. **Worker Threads (Token Ring Nodes)**
   - Each thread represents a node in the token ring.
   - Each thread continuously listens for incoming data.
   - If the thread holds the **token**, it can send data.
   - If the thread receives a packet, it checks whether it is the destination.
   - If the packet is not for the current node, it **forwards** it to the next node.

3. **Shared Memory (`malloc()` instead of `shmget()`)**
   - Instead of **System V Shared Memory**, we now use **heap-allocated shared data**.
   - All threads have access to `control->shared_ptr`, which holds the network state.

4. **Semaphores (Synchronization)**
   - **System V Semaphores** are retained for synchronization.
   - Used for:
     - Ensuring **only one thread accesses critical sections** at a time.
     - Coordinating **packet transfer** between nodes.
     - Preventing **race conditions** in shared data.

---

## **2. Packet Transmission Workflow**
The core transmission logic remains the same as in Assignment 2:

1. The **main thread** generates a packet and assigns it to a node.
2. The **token** starts at **Node 0** and moves through the network.
3. A **thread holding the token**:
   - If it has data to send, it transmits a packet.
   - If it does not have data, it forwards the token.
4. When the packet reaches its **destination node**:
   - The node **receives** the packet.
   - The token continues to circulate.
5. The **main thread waits** until all packets are delivered.
6. The **threads are joined (`pthread_join`)**, and the simulation terminates.

---

## **3. Key Code Changes**
### **3.1. Replacing `fork()` with `pthread_create()`**
#### **Old (Multi-Process)**
```c
for (int i = 0; i < N_NODES; i++) {
    pid_t pid = fork();
    if (pid == 0) {
        token_node(control, i);
        exit(0);
    }
}
```
#### **New (Multi-Threaded)**
```c
for (int i = 0; i < N_NODES; i++) {
    args[i].control = control;
    args[i].nodeIndex = i;
    pthread_create(&workers[i], NULL, worker_thread, &args[i]);
}
```
Each **node is now a thread** instead of a separate process.

---

### **3.2. Memory Allocation (`malloc()` instead of `shmget()`)**
#### ** Old (Multi-Process, Shared Memory)**
```c
int shmid = shmget(IPC_PRIVATE, sizeof(struct shared_data), IPC_CREAT | 0666);
control->shared_ptr = (struct shared_data *) shmat(shmid, NULL, 0);
```
#### **New (Multi-Threaded, Heap Allocation)**
```c
control->shared_ptr = (struct shared_data *)malloc(sizeof(struct shared_data));
```
Threads **share the heap-allocated memory**, removing the need for `shmget()`.

---

### **3.3. Using `pthread_join()` instead of `waitpid()`**
#### ** Old (Multi-Process, Waiting for Child Processes)**
```c
for (int i = 0; i < N_NODES; i++) {
    waitpid(child_pids[i], NULL, 0);
}
```
#### ** New (Multi-Threaded, Joining Threads)**
```c
for (int i = 0; i < N_NODES; i++) {
    pthread_join(workers[i], NULL);
}
```
Each **thread is explicitly joined** to ensure all nodes finish execution before exiting.

---

## **4. Debugging and Packet Tracking**
To **enable debugging and visualize packet movement**, compile the program with the `-DDEBUG` flag:

```makefile
CFLAGS = -pedantic -Wall -pthread -DDEBUG
```
When compiled in debug mode, additional messages are printed:
- When a **node receives the token**.
- When a **packet is sent and received**.
- **Semaphore synchronization logs**.

---

## **5. Simulation Execution**
The program runs with:
```sh
./tokensim <number_of_packets>
```
---

## **6. Summary of Results**
The transition from **multi-process to multi-threading** provided the following benefits:
- **Reduced memory overhead** (no need for `shmget()`).
- **Faster execution** (no expensive process switching).
- **Efficient synchronization** (threads share memory, avoiding `shmat()` overhead).
- **Simplified cleanup** (`pthread_join()` replaces `waitpid()`).

---

## **7. Conclusion**
This project successfully **converted a multi-process Token Ring Simulation into a multi-threaded simulation** while preserving correct packet transmission and synchronization.  
Threads now efficiently communicate via **heap-allocated shared data**, and **semaphores ensure proper synchronization**.  
The final implementation models a **realistic token-passing network** while benefiting from the performance advantages of **multi-threading**.

